from turtle import*
import time
import random
objects=[]
circles=[]
s=Screen()
s.setup(400,400)
s.bgcolor(237,180,7)
ai=Turtle()
ai.shape("circle")
ai.color("blue")
ai.pu()
def colliding(obj,dist=10):
  return(ai.distance(obj.pos())<=dist)
import string
import time
r=0
high=0
enemys=[]
forever=True
class Compiler(object):
  def __init__(self):
    pass
  def run(self,code):
    rc=code
    if rc[:6]=="print:":
      print(rc[6:])

class Enemy(object):
  def __init__(self,x,y):
    self.x,self.y=x,y
    self.obj=Turtle(x,y)
    self.obj.pu()
    self.obj.speed(1000)
    self.obj.shape("circle")
    self.obj.color("green")
    self.obj.setpos(x,y)
    enemys.append(self)
  def getX(self):
    return(self.x)
  def getY(self):
    return(self.y)
  def move(self):
    direction=random.randint(0,3)
    if direction==0:  
      self.obj.setpos(self.getX(),self.getY()+10)
      self.y+=10
    elif direction==1:  
      self.obj.setpos(self.getX()+10,self.getY())
      self.x+=10
    elif direction==2:  
      self.obj.setpos(self.getX()-10,self.getY())
      self.x-=10
    else:
      self.obj.setpos(self.getX(),self.getY()-10)
      self.y-=10
    coords=[self.obj.xcor(),self.obj.ycor()]
    if coords[1]<-200:
      self.obj.setpos(0,0)
    if coords[1]>200:
      self.obj.setpos(0,0)
    if coords[0]<-200:
      self.obj.setpos(0,0)
    if coords[0]>200:
      self.obj.setpos(0,0)
    if colliding(self.obj,50):
      ai.color("red")
      ai.color("blue")
      self.obj.ht()
      enemys.remove(self)
    
class Circle(object):
  def __init__(self,x,y,color):
    self.x,self.y=x,y
    self.obj=Turtle(x,y)
    self.obj.pu()
    self.obj.speed(1000)
    self.obj.shape("circle")
    self.obj.color(color)
    self.obj.setpos(x,y)
    circles.append(self)
  def check(self):
    if colliding(self.obj) and self.obj.isvisible():
      print("OW!!!")
      self.obj.hideturtle()

class Events(object):
  def __init__(self,main):
    self.main=main
    self.actions=[]
    self.events=[]
  def new(self,name,execution):
    self.actions.append(execution)
    self.events.append(name)
    
class Knowledge(object):
  def __init__(self):
    self.vals=[]
    self.variables=[]
  def learn(self,var,val):
    if var not in self.variables:
      self.variables.append(var)
      self.vals.append(self.convert(val))
  def info(self,key):
    try:  
      return(self.vals[self.variables.index(self.convert(key))])
    except:
      pass
  def convert(self,text):
    return(text)
  def change(self,key,val):
    self.vals[self.variables.index(self.convert(key))]=val
  def has(self,key):
    if key in self.variables:
      return(True)
    else:
      return(False)

class Object(object):
  def draw(x,y):
    ai.pd()
    ai.goto(x,y)
    ai.pu()
    self.x=x
    self.y=y
  def goto(x,y):
    ai.pu()
    ai.goto(x,y)
    self.x=x
    self.y=y
  def tp(self,x,y):
    ai.pu()
    ai.setpos((x,y))
    self.x=x
    self.y=y
  def getX(self):
    return(self.x)
  def getY(self):
    return(self.y)

obj=Object()
obj.tp(0,0)

def moveRandom(x,y):
  colon1=main.data.info("colonization")
  direction=random.randint(0,3)
  if direction==0:  
    obj.tp(obj.getX(),obj.getY()+main.data.info("speed"))
  elif direction==1:  
    obj.tp(obj.getX()+main.data.info("speed"),obj.getY())
  elif direction==2:  
    obj.tp(main.data.info("speed"),obj.getY())
  else:
    obj.tp(obj.getX(),obj.getY()+main.data.info("speed"))
  colon2=main.data.info("colonization")
  while not (colon1>=colon2 or main.data.info("pos:"+str(obj.getX())+","+str(obj.getY()))=="rock"):
    colon1=main.data.info("colonization")
    direction=random.randint(0,3)
    if direction==0:  
      obj.tp(obj.getX(),obj.getY()+main.data.info("speed"))
    elif direction==1:  
      obj.tp(obj.getX()+main.data.info("speed"),obj.getY())
    elif direction==2:  
      obj.tp(main.data.info("speed"),obj.getY())
    else:
      obj.tp(obj.getX(),obj.getY()+main.data.info("speed"))
    colon2=main.data.info("colonization")
  coords=[ai.ycor(),ai.xcor()]
  if coords[1]<-200:
    obj.tp(0,0)
    main.data.change("wall",True)
  if coords[1]>200:
    obj.tp(0,0)
    main.data.change("wall",True)
  if coords[0]<-200:
    obj.tp(0,0)
    main.data.change("wall",True)
  if coords[0]>200:
    obj.tp(0,0)
    main.data.change("wall",True)
  main.data.change("x",obj.getX())
  main.data.change("y",obj.getY())
  main.data.change("colonization",ai.distance(0,0))
  cx=obj.getX()
  cy=obj.getY()
  
def moveTo(x,y):
  colon1=main.data.info("colonization")
  direction=random.randint(0,3)
  if direction==0:  
    obj.tp(obj.getX(),obj.getY()+main.data.info("speed"))
  elif direction==1:  
    obj.tp(obj.getX()+main.data.info("speed"),obj.getY())
  elif direction==2:  
    obj.tp(main.data.info("speed"),obj.getY())
  else:
    obj.tp(obj.getX(),obj.getY()+main.data.info("speed"))
  colon2=main.data.info("colonization")
  while not (colon1>=colon2 or main.data.info("pos:"+str(obj.getX())+","+str(obj.getY()))=="rock" and ai.dist((x,y))>=30):
    colon1=main.data.info("colonization")
    direction=random.randint(0,3)
    if direction==0:  
      obj.tp(obj.getX(),obj.getY()+main.data.info("speed"))
    elif direction==1:  
      obj.tp(obj.getX()+main.data.info("speed"),obj.getY())
    elif direction==2:  
      obj.tp(main.data.info("speed"),obj.getY())
    else:
      obj.tp(obj.getX(),obj.getY()+main.data.info("speed"))
    colon2=main.data.info("colonization")
  coords=[ai.ycor(),ai.xcor()]
  if coords[1]<-200:
    obj.tp(0,0)
    main.data.change("wall",True)
  if coords[1]>200:
    obj.tp(0,0)
    main.data.change("wall",True)
  if coords[0]<-200:
    obj.tp(0,0)
    main.data.change("wall",True)
  if coords[0]>200:
    obj.tp(0,0)
    main.data.change("wall",True)
  main.data.change("x",obj.getX())
  main.data.change("y",obj.getY())
  main.data.change("colonization",ai.distance(0,0))
  cx=obj.getX()
  cy=obj.getY()
  
class Main(object):
  def __init__(self):
    self.events=Events(self)
    self.compiler=Compiler()
    self.data=Knowledge()
main=Main()
main.data.learn("greet","Hello, World!")
main.data.learn("x",obj.getX())
main.data.learn("y",obj.getY())
main.data.learn("colonization",0)
main.data.learn("speed",10)
main.data.learn("wall",False)
main.events.new("start","print:"+main.data.info("greet"))
for i in range(len(main.events.actions)):
    if main.events.events[r]=="start":
      main.compiler.run(main.events.actions[r])
    r+=1
#for x in range(-200,200,20):
#  for y in range(-200,200,20):
#    objects.append(Circle(x,y,random.choice(["orange","purple","yellow","red","green","blue"])))
for i in range(25):
  objects.append(Circle(random.randint(-200,200),random.randint(-200,200),"gray"))
for item in circles:
  if colliding(item.obj,50):
    main.data.learn("pos:"+str(item.x)+","+str(item.y),"rock")
while True:
  r=0
  for i in range(len(main.events.actions)):
    if main.events.events[r]!="start":
      if main.events.events[r]:
        main.compiler.run(main.events.actions[r])
    r+=1
  for item in circles:
    item.check()
  main.data.change("x",obj.getX())
  main.data.change("y",obj.getY())
  main.data.change("colonization",ai.distance(0,0))
  if main.data.info("wall"):
    if int(round(time.time() * 1000))%1000==0:
      Enemy(random.randint(-200,200),random.randint(-200,200))
      ai.stamp()
  else:
    moveRandom(obj.getX(),obj.getY())
  if high<ai.distance(0,0):
    high=ai.distance(0,0)
    print("Imporoved Colonizaton:"+str(round(high))+"!")
  for item in circles:
    if colliding(item.obj,50):
      main.data.learn("pos:"+str(item.x)+","+str(item.y),"rock")
  for item in enemys:
    item.move()
  moveTo(200,0)