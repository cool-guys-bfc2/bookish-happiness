var page=0;
var money=0;
const pages=["SWORDS AND AXES","Welcome to hero!","Hero is a world of advenutre of goood and evil!","Press option 1 to be evil! Press option 2 to be good!","You have 5 loaves of bread, and 1 pickaxe!","Night Time!","A Zombie just aproached!","Fight or move!","The next day you got a cut!","Heal or move?","That was a good idea!","Look some gold and a sword!","Opt. 1 for take and Opt. 2 for move!"];
const items = ['food','food','food','food','food','pickaxe'];
function module(n) {
  if(n=="sound") {
    return {
      play:function (f) {
        const sound=Audio(f);
        sound.play();
      }
    };
  }
  if(n=="game") {
    return {
      text:function (t) {
        const px=document.createElement("p");
        px.innerText=t;
        document.getElementById("bg").appendChild(px);
      }
    };
  }
}
function cash(amount) {
  document.getElementById("cash").hidden=false;
  money+=amount;
  document.getElementById("m").innerText="$"+money;
}
function next() {
  page+=1;
  document.getElementById("bg").innerText=pages[page];
  if(document.getElementById("bg").innerText=="undefined") {
    document.getElementById("bg").innerText="TO BE CONTINUED!!!!!";
    document.getElementById("next").hidden=true;
    document.getElementById("sel1").hidden=true;
    document.getElementById("sel2").hidden=true;
    document.getElementById("sel3").hidden=true;
  }
  document.getElementById("cash").hidden=true;
}
function sel(s) {
  if(page==3) {
    if(s==1) {
      document.getElementById("bg").innerText="You Lose!";
      document.getElementById("next").hidden=true;
      document.getElementById("sel1").hidden=true;
      document.getElementById("sel2").hidden=true;
      document.getElementById("sel3").hidden=true;
    }
    if(s==2) {
      document.getElementById("bg").innerText="Good! Evil could kill you!";
      cash(500);
    }
  }
  if(page==7) {
    if(s===2) {
      document.getElementById("bg").innerText="You Lose!";
      document.getElementById("next").hidden=true;
      document.getElementById("sel1").hidden=true;
      document.getElementById("sel2").hidden=true;
      document.getElementById("sel3").hidden=true;
    }
    if(s==1) {
      document.getElementById("bg").innerText="Phew! You could have beeen eaten back there!";
      cash(25);
    }
  }
  if(page==9) {
    if(s===2) {
      document.getElementById("bg").innerText="You Lose!";
      document.getElementById("next").hidden=true;
      document.getElementById("sel1").hidden=true;
      document.getElementById("sel2").hidden=true;
      document.getElementById("sel3").hidden=true;
    }
    if(s==1) {
      document.getElementById("bg").innerText="Phew! You could have got a concussion!";
      cash(25);
    }
  }
  if(page==12) {
    if(s===2) {
      document.getElementById("bg").innerText="You Lose! The sword slashed you with it's magic!";
      document.getElementById("next").hidden=true;
      document.getElementById("sel1").hidden=true;
      document.getElementById("sel2").hidden=true;
      document.getElementById("sel3").hidden=true;
    }
    if(s==1) {
      document.getElementById("bg").innerText="Good job!";
      items.push('sword');
      cash(3000);
    }
  }
}
const ge=module("game");
ge.text(pages[0]);