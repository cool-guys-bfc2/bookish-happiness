from processing import *
import random,time,math,string
xp=0
attack=False
grid=64
fps=60
places=[]
items={
}

def readdisk():
  return open('save.txt','r').read()

def writedisk(x):
  f=open('save.txt','w')
  if type(x)==str:
    f.write(x)
  elif type(x)==list:
    f.write('\n'.join(x))
  f.close()

def check():
  global items
  x=True
  for i in items:
    if 0>=items[i]:
      x=False
    if 0==items[i]:
      x=True
    if 0>=items[i]:
      del items[i]
  return x

def give(i,x):
  global items
  if i in items:
    items[i]+=x
  else:
    items[i]=x
  check()

def clear(i,x):
  global items
  if i in items:
    if items[i]>=x:
      items[i]-=x
      return True
    else:
      return False
  else:
    return False
  check()

start_menu = True
game_load_type = ''
new_player_made = False

def getIndent(x):
  r=0
  for i in x:
    if i==' ':
      r+=1
    else:
      break
  return r

def decode(x):
  try:
    return {y.split('=')[0]:y.split('=')[1] for y in x.split('&')}
  except:
    return {}

def encode(x):
  return string.join([i+'='+str(x[i]) for i in x],'&')

def parseData(x):
  r={
    'item':{
    },
    'npc':{
      
    }
  }
  t='none'
  s='none'
  e='none'
  for i in x:
    a=i.split(' ')
    d=[]
    if a[0]=='data':
      r[s][t].append(decode(string.join(a[1].split('\n'),'')))
    if a[0]=='code':
      d.append({'code':string.join(string.join(a[1:],'').split('\n'),'')})
    if a[0]=='event':
      d.insert(0,{'event':string.join(a[1].split('\n'),'')})
      for i2 in d:
        r[s][t].append(i2)
      e='none'
      e=string.join(a[1].split('\n'),'')
      d[:]=[]
    if a[0]=='class':
      s=string.join(a[1].split('\n'),'')
      t=string.join(a[2].split('\n'),'')
      try:
        r[s][t]=d
      except:
        pass
      s='none'
      t='none'
      s=string.join(a[1].split('\n'),'')
      t=string.join(a[2].split('\n'),'')
      d[:]=[]
  d.insert(0,{'event':e})
  #r[s][t]=d
  for i2 in d:
    r[s][t].append(i2)
  del r[s][t][len(r[s][t])-1]
  return r

data=parseData(open('data.txt','r').readlines())

print(data)

images={}
bps=[]

def addXp(a):
  global xp
  xp+=a

def spend(amount):
  global xp
  val=(xp>=amount)
  if val:
    xp-=amount
  return val

def reset(person):
  person.health=20
  person.damage=2

def randomplaceonscreen():
  return random.randint(0,grid-grid%1)*50

objects=[]
blocks=[]
blockpos={}
gui=[]
bptuple=[]

p1=''

def saveGame(player):
  x=''
  x+=encode(player.sd)
  writedisk(x)

def loadGame():
  global p1
  x=readdisk()
  x=x.split('\n')
  y=decode(x[0])
  p1.x,p1.y,p1.ax,p1.ay=int(y['x']),int(y['y']),int(y['ax']),int(y['ay'])
  p1.health=int(y['hp'])
  p1.damage=int(y['damage'])
  p1.showed=y['show']
  p1.maxhp=int(y['maxhp'])
  p1.level=int(y['level'])
  for i in objects:
    i.x+=250
    i.y-=250
  for k in blocks:
    i=k
    i.x+=250
    i.y-=250
  #except:
  #  print('Nothing has been saved or the save data is invalid.')
  

class Block(object):
  def __init__(self,x,y,r,g,b):
    self.x=x
    self.y=y
    self.r=r
    self.g=g
    self.b=b
    blocks.append(self)
    blockpos[str(x)+','+str(y)]=self
  def show(self):
    fill(self.r,self.g,self.b)
    rect(self.x,self.y,50,50)
    
class GenerationBlock(object):
  def __init__(self,x,y,r,g,b,i=0):
    self.i=0
    global grid
    self.x=x
    self.y=y
    self.r=r
    self.g=g
    self.b=b
    if (self.x,self.y) not in bptuple:
      blocks.append(self)
      bptuple.append((self.x,self.y))
    self.dist=abs(grid/2-self.x)/50+abs(grid/2-self.y)/50
    if grid<self.dist:
      grid=self.dist
    blockpos[str(x)+','+str(y)]=self
  def show(self):
    fill(self.r,self.g,self.b)
    rect(self.x,self.y,50,50)

class Player(object):
  def __init__(self):
    self.damage=4
    self.health=20
    self.x=grid*25
    self.y=grid*25
    self.ax=self.x
    self.ay=self.y
    self.showed=True
    self.maxhp=20
    self.level=1
    self.xp=xp
    self.sd={}
  def r(self,ox,oy,sx,sy,r,g,b):
    fill(r,g,b)
    rect(250+ox,250+oy,sx,sy)
  def show(self):
    if self.showed:
      noFill()
      image(images['player'],250,250,50,50)
    if self.health<=0:
      reset(self)
    self.xp=xp
    self.level=round(((len(str(self.xp))*10)-10+int(str(self.xp)[len(str(self.xp))-1]))/10)
    self.sd={
      'damage':self.damage,
      'hp':self.health,
      'x':self.x,'y':self.y,
      'ax':self.ax,'ay':self.ay,
      'show':self.showed,
      'maxhp':self.maxhp,
      'level':self.level
    }
  def move(self,x,y):
    if self==p1:
      self.x+=x
      self.y-=y
      self.ax+=x
      self.ay+=y
      for i in objects:
        i.x-=x
        i.y+=y
      for k in blockpos:
        i=blockpos[k]
        i.x-=x
        i.y+=y

p=[]

class Ball(object):
  def __init__(self,x,y):
    self.x=x
    self.y=y
    self.showed=True
  def r(self,ox,oy,sx,sy,r,g,b):
    fill(r,g,b)
    rect(self.x+ox,self.y+oy,sx,sy)
  def destroy(self):
    objects.remove(self)
  def oninteract(self):
    global xp,items
    xp+=1
    objects.append(Ball(randomplaceonscreen(),randomplaceonscreen()))
    give('wood',1)
    print(items)
    self.destroy()
  def show(self):
    global xp
    if self.showed:
      self.r(0,0,50,50,255,0,0)
    if self.touchingPlayer() and attack:
      self.oninteract()
  def move(self,x,y):
    self.x+=x
    self.y+=y
  def touchingPlayer(self):
    return 250==self.x and 250==self.y

class NPC1(object):
  def __init__(self,x,y):
    self.x=x
    self.y=y
    self.showed=True
  def r(self,ox,oy,sx,sy,r,g,b):
    fill(r,g,b)
    rect(self.x+ox,self.y+oy,sx,sy)
  def destroy(self):
    objects.remove(self)
  def info(self,t):
    textSize(10)
    text(t,0,100)
    textSize(50)
  def oninteract(self):
    global xp
    self.info("Hi! Explore, interact(SPACE) on the ore for XP to buy stuff!")
  def show(self):
    global xp
    if self.showed:
      noFill()
      image(images['npc'],self.x,self.y,50,50)
    if self.touchingPlayer() and attack:
      self.oninteract()
  def move(self,x,y):
    self.x+=x
    self.y+=y
  def touchingPlayer(self):
    return 250==self.x and 250==self.y

class NPC(object):
  def __init__(self,d,x,y):
    self.d=d
    self.x=x
    self.y=y
    self.showed=True
    self.interact=[]
    self.init=[]
    event=''
    for i in self.d:
      if 'event' in i:
        event=i['event']
      else:
        if event=='root:interact':
          if 'code' in i:
            self.interact.append(i['code'])
        if event=='root:init':
          if 'code' in i:
            self.init.append(i['code'])
    for i in self.init:
      self.code(i)
  def code(self,x):
    a=x.split('>')
    if a[0]=='info':
      self.info(a[1])
  def r(self,ox,oy,sx,sy,r,g,b):
    fill(r,g,b)
    rect(self.x+ox,self.y+oy,sx,sy)
  def destroy(self):
    objects.remove(self)
  def info(self,t):
    textSize(10)
    text(t,0,100)
    textSize(50)
  def oninteract(self):
    global xp
    for i in self.init:
      self.code(i)
  def show(self):
    global xp
    if self.showed:
      noFill()
      image(images['npc'],self.x,self.y,50,50)
    if self.touchingPlayer() and attack:
      self.oninteract()
  def move(self,x,y):
    self.x+=x
    self.y+=y
  def touchingPlayer(self):
    return 250==self.x and 250==self.y

class Ore(object):
  def __init__(self,x,y):
    self.x=x
    self.y=y
    self.showed=True
  def r(self,ox,oy,sx,sy,r,g,b):
    fill(r,g,b)
    rect(self.x+ox,self.y+oy,sx,sy)
  def destroy(self):
    objects.remove(self)
  def info(self,t):
    text(t,0,100)
  def oninteract(self):
    global xp
    xp+=1
  def show(self):
    global xp
    if self.showed:
      noFill()
      image(images['ore'],self.x,self.y,50,50)
    if self.touchingPlayer() and attack and millis()%25==0:
      self.oninteract()
  def move(self,x,y):
    self.x+=x
    self.y+=y
  def touchingPlayer(self):
    return 250==self.x and 250==self.y

class EnemyBase(object):
  def __init__(self,x,y):
    objects.append(self)
    self.reward=3
    self.damage=0
    self.health=20
    self.data(x,y)
    self.x=x
    self.y=y
    self.showed=True
  def r(self,ox,oy,sx,sy,r,g,b):
    fill(r,g,b)
    rect(self.x+ox,self.y+oy,sx,sy)
  def destroy(self):
    objects.remove(self)
  def show(self):
    global xp
    if self.showed:
      self.r(0,0,50,50,0,225,0)
    if self.touchingPlayer():
      self.data(self.x,self.y)
      fill(0)
      text(str(self.health),0,100)
      if  millis()%200==0:
        if attack:
          self.destroy()
          xp+=self.reward
      if  millis()%500==0:
        if not attack:
          p1.health-=self.damage
      if self.health<=0:
        self.destroy()
    else:
      if millis()%500==0:
        self.x+=random.randint(0,2)*50
        self.y+=random.randint(0,2)*50
  def move(self,x,y):
    self.x+=x
    self.y+=y
  def touchingPlayer(self):
    return 250==round(self.x) and 250==round(self.y)
  def data(self):
    pass

cid=1
p2=1

class Button(object):
  def __init__(self,c,x,y,w,h,text=''):
    global cid
    self.c=c
    self.x,self.y=x,y
    self.w,self.h=w,h
    self.t=text
    self.show()
    self.pin=cid
    print(self.pin)
    cid+=1
    gui.append(self)
  def show(self):
    self.shown=True
  def hide(self):
    self.shown=False
  def display(self):
    if self.shown:
      fill(self.c)
      rect(self.x,self.y-self.h,self.w,self.h)
      fill(color(255,255,255))
      textSize(self.h)
      text(self.t,self.x,self.y)
  def isclicked(self,mx,my):
    global p2
    res=(round(mx/(self.w*2))*(self.w*2)==round(self.x/(self.w*2))*(self.w*2))
    res=res and (round((my+self.h)/(self.h*2))*(self.h*2)==round(self.y/(self.h*2))*(self.h*2))
    res=(res and p2==self.pin)
    return res

class Goblin(EnemyBase):
  def data(self,x,y):
    self.pos=(x,y)
    self.health=15
    self.damage=1

objects[:]=[
  Ball(randomplaceonscreen(),randomplaceonscreen()),
  Ball(randomplaceonscreen(),randomplaceonscreen()),
  Ball(randomplaceonscreen(),randomplaceonscreen()),
  Ball(randomplaceonscreen(),randomplaceonscreen()),
  Ball(randomplaceonscreen(),randomplaceonscreen()),
  NPC1(0,0),
  Ore(50,0)
]

def setup():
  global places
  size(500,500)
  Goblin(250,500)
  frameRate(fps)
  images['player']=loadImage('player.gif')
  images['npc']=loadImage('player.png')
  images['ore']=loadImage('ore.png')
  images['cursor']=loadImage('cursor.png')
  r,g,b=0,0,0
  gt=0
  if gt==0:
    for x in range(grid):
      for y in range(grid):
        r=random.randint(55,175)
        g=random.randint(187,225)
        b=random.randint(55,125)
        Block(x*50,y*50,r,g,b)
    locx=grid/2
    locy=grid/2
    sx=grid/5
    sy=grid/5
    r,g,b=0,0,0
    for x in range(round(locx-sx),round(locx)):
      for y in range(round(locy-sy),round(locy)):
        r=0
        g=random.randint(97,225)
        b=random.randint(187,225)
        Block(x*50,y*50,r,g,b)
  if gt==1:
    nspreads=random.randint(5,10)
    spreads=[]
    for i in range(nspreads):
      spreads.append(GenerationBlock(randomplaceonscreen(),randomplaceonscreen(),random.randint(55,175),random.randint(187,225),random.randint(55,125)))

def keyPressed():
  global attack,p2, start_menu, load_game_type,p1
  
  if start_menu:
    
    if key == "n" or key == "N":
      
      p1=Player()
      p.append(p1)

      start_menu = False
      load_game_type = "NEW"
      
    if key == "l" or key == "L":
      p1=Player()
      p.append(p1)
      loadGame()
      start_menu = False
      load_game_type = "LOAD"  
    
  
  if key == "s" and not start_menu:
    saveGame(p1)
  
  if key==' ':
    attack=True
  if key==CODED:
    if keyCode==UP:
      p1.move(0,50)
    if keyCode==DOWN:
      p1.move(0,-50)
    if keyCode==LEFT:
      p1.move(-50,0)
    if keyCode==RIGHT:
      p1.move(50,0)
  if key=='w':
    p2+=1
  if key=='s':
    p2-=1

def keyReleased():
  global attack
  attack=False
    
def draw():
  global grid, new_player_made,game_load_type,p1
  
  if start_menu:
    
    textSize(50)
    fill(255, 0, 0)
    text("BATTLE BEASTS", 50, 200)
    
    textSize(25)
    fill(0, 255, 0)
    text("Press N to start a new game", 100, 300)
    fill(0, 0, 255)
    text("Press L to load a saved game", 100, 350)
    
  elif game_load_type == "LOAD":
    
    #load the player data
    #print it to verify
    
    background(0,215,0)
    fill(0)
    #noCursor()
    textSize(50)
    for i in blocks:
      i.show()
    for i in p:
      i.show()
    for i in objects:
      i.show()
    if random.randint(0,10)==0 and millis()%1000==0:
      Goblin(randomplaceonscreen(),randomplaceonscreen())
    for i in gui:
      i.display()
    fill(0)
    textSize(50)
    text(str(p1.ax)+","+str(p1.ay)+',hp'+str(p1.health),0,50)
    text(str(xp)+'XP'+' lvl'+str(p1.level),0,150)
    #text(str(p2),200,100)
    """r,g,b=0,0,0
    for lx in range(p1.x,p1.x+250,50):
      for ly in range(p1.y,p1.y+250,50):
        r=random.randint(55,175)
        g=random.randint(187,225)
        b=random.randint(55,125)
        Block(lx,ly,r,g,b)"""
        
  else: #new game
      #print new player data
    background(0,215,0)
    fill(0)
    #noCursor()
    textSize(50)
    for i in blocks:
      i.show()
    for i in p:
      i.show()
    for i in objects:
      i.show()
    if random.randint(0,10)==0 and millis()%1000==0:
      Goblin(randomplaceonscreen(),randomplaceonscreen())
    for i in gui:
      i.display()
    fill(0)
    textSize(50)
    text(str(p1.ax)+","+str(p1.ay)+',hp'+str(p1.health),0,50)
    text(str(xp)+'XP'+' lvl'+str(p1.level),0,150)
    #text(str(p2),200,100)
    """r,g,b=0,0,0
    for lx in range(p1.x,p1.x+250,50):
      for ly in range(p1.y,p1.y+250,50):
        r=random.randint(55,175)
        g=random.randint(187,225)
        b=random.randint(55,125)
        Block(lx,ly,r,g,b)"""
  """if not start_menu:
    if millis()%5000==0:
      try:
        saveGame(p1)
      except:
        print('Could not save game.')"""
  
run()