from processing import*
import time
import random
import math

planet_x=range(-25000,25000)
planet_y=range(-25000,251000)
planet_z=range(-25000,25000)
planet_r=range(0,255)       
planet_g=range(0,255)
planet_b=range(0,255)
def cl(list):
  return(random.choice(list))
  
def getColor():
  return(cl(planet_r))
  
def getPosition():
  return(cl(planet_x))

def planet(XO,YO,ZO,r,g,b,size):
  pushMatrix()
  fill(r,g,b)
  stroke(255)
  translate(XO+x,YO+y,ZO+z)
  sphere(size)
  popMatrix()
  
def rgb_red():
  return(255,0,0)
def rgb_green():
  return(0,255,0)
def rgb_blue():
  return(0,0,255)
def rgb_purple():
  return(255,0,255)
def rgb_yellow():
  return(0,255,255)
def rgb_black():
  return(0,0,0)
def rgb_white():
  return(255,255,255)

def delay(seconds):
  time.sleep(seconds)

def millisec(ms):
  return(time.millis()%ms==0)
   
class Calc(object):
  def sr(self,num):
    return(sqrt(num))
  def add(a,b):
    if type(a+b)==type(7):
      return(a+b)
  def subtract(self,a,b):
    return(a-b)
  def mult(a,b):
    return(a*b)
  def divide(self,a,b):
    return(a/b)
  def mod(self,a,b):
    return(a%b)
  def exponet(self,a,b):
    return(a**b)
  
class Console:
  def __init__(self):
    self.said="none"
    self.answer="none"
    self.asked="none"
    self.consoled="none"
  def say(self,string):
    print(string)
    self.said=string
    self.consoled=string
  def ask(self,string):
    self.answer=input(string)
    self.asked=string
    self.consoled=string
  def getAnswer(self):
    return(self.answer)

def setup():
  global rotation,z,x,y,planets,cpd,size,calc,console
  size(400,400,P3D)
  rotation=0
  z=-1000
  x=200
  y=200
  planets=[[getPosition(),getPosition(),getPosition()],
           [getPosition(),getPosition(),getPosition()],
           [getPosition(),getPosition(),getPosition()],
           [getColor(),getColor(),getColor()],
           [getColor(),getColor(),getColor()],
           [getColor(),getColor(),getColor()]]
  cpd=[]
  size=[random.randint(50,175),random.randint(50,175),random.randint(50,175)]
  for i in range(0,700,1):
    planet_x.remove(i)
    planet_y.remove(i)
    planet_z.remove(i)
  for i in range(1,700,1):
    planet_x.remove(-i)
    planet_y.remove(-i)
    planet_z.remove(-i)
  console=Console()
  calc=Calc()
  for i in range(98):
    planets[0].append(getPosition())

def draw():
  global rotation,z,y,x
  background(0)
  distance=abs(x)+abs(y)+abs(z)
  distance_miles=round((calc.sr(distance)))*1000
  planet(0,0,0,55,225,255,375)
  planet(1000,1000,0,0,255,0,125)
  planet(-750,-750,0,0,0,0,125)
  for i in range(0,2,1):
    cpd[:]=[]
    cpd.append(planets[0][i])
    cpd.append(planets[1][i])
    cpd.append(planets[2][i])
    cpd.append(planets[3][i])
    cpd.append(planets[4][i])
    cpd.append(planets[5][i])
    planet(cpd[0],cpd[1],cpd[2],cpd[3],cpd[4],cpd[5],size[i])
  timeK=millis()
  if timeK%25==0:
    rotation+=1
  popMatrix()
  textSize(25)
  fill(5,225,255)
  text("Z:"+str(z),0,75)
  text("Y:"+str(y),0,50)
  text("X:"+str(x),0,25)
  text(str(distance_miles)+" miles",0,100)
  pushMatrix()
  if distance<=700:
    exit()

def keyPressed():
  global z,x,y
  if key==" ":
    y+=10
  if key==CODED:
    if keyCode==UP:
     z+=10
    if keyCode==DOWN:
     z-=10
    if keyCode==LEFT:
     x+=10
    if keyCode==RIGHT:
     x-=10
    if keyCode==SHIFT:
      y-=10
  if key=="t":
    console.ask("Choose your X!")
    x=console.getAnswer()
    console.ask("Choose your Y!")
    y=console.getAnswer()
    console.ask("Choose your Z!")
    z=console.getAnswer()

run()