from processing import*
import math
import time
images=[]

def load(image):
  if loadImage(image) in images:
   images.append(loadImage(image))
   
def rgb_red():
  return(255,0,0)
def rgb_green():
  return(0,255,0)
def rgb_blue():
  return(0,0,255)
def rgb_purple():
  return(255,0,255)
def rgb_yellow():
  return(0,255,255)
def rgb_black():
  return(0,0,0)
def rgb_white():
  return(255,255,255)

def delay(seconds):
  time.sleep(seconds)

def millisec(ms):
  return(time.millis()%ms==0)
   
class Calc(object):
  def sr(self,num):
    return(math.sqrt(num))
  def add(a,b):
    if type(a+b)==type(7):
      return(a+b)
  def subtract(self,a,b):
    return(a-b)
  def mult(a,b):
    return(a*b)
  def divide(self,a,b):
    return(a/b)
  def mod(self,a,b):
    return(a%b)
  def exponet(self,a,b):
    return(a**b)
  
class Console:
  def __init__(self):
    self.said="none"
    self.answer="none"
    self.asked="none"
    self.consoled="none"
  def say(self,string):
    print(string)
    self.said=string
    self.consoled=string
  def ask(self,string):
    self.answer=input(string)
    self.asked=string
    self.consoled=string
  def getAnswer(self):
    return(self.answer)