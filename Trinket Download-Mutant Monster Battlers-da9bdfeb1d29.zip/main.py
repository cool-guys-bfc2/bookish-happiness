import string
import math
def load():
  fr=open("db.txt","r")
  result={}
  raw=fr.read()
  split_text = raw.split("\n")
  clean_text = "".join(split_text)
  raw=clean_text
  if raw=="":
    return({})
  else:
    for pair in raw.split("&"):
      kav=pair.split("=")
      result[kav[0]]=kav[1]
  fr.close()
  return(result)
data={}
data=load()
def saveDB():
  result=[]
  for key in data:
    result.append(str(key)+"="+data[str(key)])
  result=string.join(result,"&")
  fw=open("db.txt","w")
  fw.write(result)
  fw.close()
from processing import*
import time
import random
try:
  xp=int(data["xp"])
except:
  xp=0
  data["xp"]=str(xp)
  saveDB()
  
try:
  health=int(data["health"])
except:
  health=30
  data["health"]=str(health)
  saveDB()
  
offscreen=[]
onscreen=[]

def nearestPixel(x,y,scale=10):
  return([math.floor(x/scale)*scale,math.floor(y/scale)*scale])

class Image(object):
  def __init__(self,x,y):
    self.x=x
    self.y=y
    self.onscreen()
    self.init()
  def onscreen(self):
    try:
      onscreen.append(self)
      offscreen.remove(self)
    except:
      onscreen.append(self)
  def check(self):
    if 0<=self.x<=400 and 0<=self.y<=400:
      if self in offscreen:
        self.onscreen()
    else:
      if self in onscreen:
        self.offscreen()
  def offscreen(self):
    try:
      offscreen.append(self)
      onscreen.remove(self)
    except:
      offscreen.append(self)
    self.x=200
    self.y=200

class Text(object):
  def __init__(self,args):
    self.x=args["x"]
    self.y=args["y"]
    self.s=args["s"]
    self.t=args["t"]
  def display(self):
    textSize(self.t)
    text(self.t,self.x,self.y)

class ButtonFunctions(object):
  def __init__(self):
    pass 
  def run(self,fun,args):
    if fun=="print-debug":
      print(args["text"])

bf=ButtonFunctions()

class Button(object):
  def __init__(self,args):
    self.x=args["x"]
    self.y=args["y"]
    self.w=args["w"]
    self.h=args["h"]
    self.r=args["r"]
    self.g=args["g"]
    self.b=args["b"]
    self.f=args["fun"]
    self.args=args["fargs"]
  def display(self):
    fill(self.r,self.g,self.b)
    rect(self.x,self.y,self.w,self.h)
  def check(self,mx,my):
    min_x=self.x
    min_y=self.y
    max_x=self.x+self.w
    max_y=self.y+self.h
    if min_x<=mx<=max_x and min_y<=my<=max_y:
      self.click()
  def click(self):
    bf.run(self.f,self.args)
 
 
    
class Screen(object):
  def __init__(self,data):
    self.btns=data["btn"][:]
    self.text=data["text"][:]
  def display(self):
    for btn in self.btns:
      btn.display()
    for text in self.text:
      text.display()
    
screens={
  "blank":Screen({
    "btn":[
      Button({"x":200,"y":0,"w":50,"h":50,"r":0,"g":0,"b":255,"fun":"print-debug","fargs":{"text":"Hi!"}})
    ],
    "text":[
    ]
    }
  )
}
s_screen=screens["blank"]
    
class Orca(Image):
  def pixel(self,x,y):
    rect((self.x-200)+200+(x*10),(200+(self.y-200))-(y*10),10,10)
  def display(self):
    fill(255,255,255)
    self.pixel(1,0)
    fill(1,8,31)
    if millis()%100>=50:
      self.pixel(3,0)
    self.pixel(-4,-1)
    self.pixel(-4,1)
    self.pixel(0,0)
    self.pixel(-2,0)
    self.pixel(-3,0)
    self.pixel(-3,-1)
    self.pixel(-3,1)
    self.pixel(0,-2)
    self.pixel(2,-2)
    self.pixel(0,2)
    self.pixel(1,2)
    self.pixel(0,1)
    self.pixel(1,1)
    self.pixel(2,1)
    self.pixel(0,1)
    self.pixel(-1,1)
    self.pixel(-1,0)
    self.pixel(2,0)
    self.pixel(-1,-1)
    self.pixel(0,-1)
    self.pixel(1,-1)
    self.pixel(2,-1)
    self.pixel(3,1)
    self.pixel(3,-1)
  def init(self):
    self.health=30
    self.dead=False
    
class Whale(Image):
  def pixelSize(self,x,y,s):
    rect((self.x-200)+200+(x*s),(200+(self.y-200))-(y*s),s,s)
  def pixel(self,x,y):
    rect((self.x-200)+200+(x*25),(200+(self.y-200))-(y*25),25,25)
  def display(self):
    fill(2,17,179)
    if millis()%50>=25:
      self.pixel(3,0)
    self.pixel(-4,-1)
    self.pixel(-4,1)
    self.pixel(0,0)
    self.pixel(-2,0)
    self.pixel(-3,0)
    self.pixel(-3,-1)
    self.pixel(-3,1)
    self.pixel(0,-2)
    self.pixel(2,-2)
    self.pixel(0,1)
    self.pixel(1,1)
    self.pixel(2,1)
    self.pixel(0,1)
    self.pixel(-1,1)
    self.pixel(-1,0)
    self.pixel(2,0)
    self.pixel(-1,-1)
    self.pixel(0,-1)
    self.pixel(1,-1)
    self.pixel(2,-1)
    self.pixel(3,1)
    self.pixel(3,-1)
    if millis()%100==0:
      self.direction=random.randint(1,4)
      if self.direction==1:
        self.x-=10
      if self.direction==2:
        self.x+=10
      if self.direction==3:
        self.y-=10
      if self.direction==4:
        self.y+=10
      for item in onscreen:
        if item!=self and (type(item)!=Orca or type(item)!=Whale):
          if item.x==self.x and item.y==self.y:
            onscreen.remove(item)
    fill(255,255,255)
    self.pixel(1,0)
  def init(self):
    self.health=30
    self.dead=False 

fishDict={}

class Shark(Image):
  def pixel(self,x,y,w=1,h=1):
    rect((self.x-200)+200+(x*w*7),(200+(self.y-200))-(y*h*7),w*9,h*9)
  def eye(self,x,y):
    rect((self.x-200)+200+(x*10)-4,(200+(self.y-200))-((y*10)+2),10,10)
  def display(self):
    rectMode(CENTER)
    stroke(0,0,0)
    noFill()
    self.pixel(0,-0.1,6,5)
    noStroke()
    rectMode(CORNER)
    fill(86,103,130)
    self.pixel(0,0)
    self.pixel(-2,0)
    self.pixel(-3,0)
    self.pixel(-3,-1)
    self.pixel(-3,1)
    self.pixel(0,-2)
    self.pixel(2,-2)
    self.pixel(0,2)
    self.pixel(1,2)
    self.pixel(0,1)
    self.pixel(1,1)
    self.pixel(2,1)
    self.pixel(0,1)
    self.pixel(-1,1)
    self.pixel(-1,0)
    self.pixel(2,0)
    self.pixel(-1,-1)
    self.pixel(0,-1)
    self.pixel(1,-1)
    self.pixel(2,-1)
    fill(255,255,255)
    self.eye(1,0)
    if millis()%100==0:
      self.direction=random.randint(1,4)
      if self.direction==1:
        self.x-=10
      if self.direction==2:
        self.x+=10
      if self.direction==3:
        self.y-=10
      if self.direction==4:
        self.y+=10
      self.min_x=(self.x-200)+200+(-3*7)
      self.min_y=(200+(self.y-200))-(-1*7)
      self.max_x=(self.x-200)+200+(2*7)
      self.max_y=(200+(self.y-200))-(2*7)
      self.check()
  def init(self):
    self.health=15
    self.max_health=15
    self.dead=False
    self.min_x=(self.x-200)+200+(-3*7)
    self.min_y=(200+(self.y-200))-(-1*7)
    self.max_x=(self.x-200)+200+(2*7)
    self.max_y=(200+(self.y-200))-(2*7)
  def check(self):
    try:
      if str(nearestPixel(self.x,self.y,7))+","+str(self.x,self.y,7) in fishDict:
        onscreen.remove(fishDict[str(self.x)+","+str(self.y)])
    except:
      pass


class Fish(Image):
  def pixel(self,x,y,w=0.25,h=0.25):
    rect((self.x-200)+200+(x*w*10),(200+(self.y-200))-(y*h*10),w*10,h*10)
  def display(self):
    fill(86,103,130)
    self.pixel(0,0)
    self.pixel(-2,0)
    self.pixel(-3,0)
    self.pixel(-3,-1)
    self.pixel(-3,1)
    self.pixel(0,-2)
    self.pixel(2,-2)
    self.pixel(0,2)
    self.pixel(1,2)
    self.pixel(0,1)
    self.pixel(1,1)
    self.pixel(2,1)
    self.pixel(0,1)
    self.pixel(-1,1)
    self.pixel(-1,0)
    self.pixel(2,0)
    self.pixel(-1,-1)
    self.pixel(0,-1)
    self.pixel(1,-1)
    self.pixel(2,-1)
    index=str(self.x)+","+str(self.y)
    try:
      del fishDict[index]
      fishDict[str(nearestPixel(self.x,self.y,2.5)[0])+","+str(nearestPixel(self.x,self.y,2.5)[1])]=self
      self.check()
    except:
      pass
    if millis()%100==0:
      self.direction=random.randint(1,4)
      if self.direction==1:
        self.x-=10
      if self.direction==2:
        self.x+=10
      if self.direction==3:
        self.y-=10
      if self.direction==4:
        self.y+=10
  def init(self):
    self.health=5
    self.max_health=5
    self.dead=False
    fishDict[str(nearestPixel(self.x,self.y,2.5)[0])+","+str(nearestPixel(self.x,self.y,2.5)[1])]=self
  def kill(self):
    try:
      del fishDict[str(nearestPixel(self.x,self.y,2.5)[0])+","+str(nearestPixel(self.x,self.y,2.5)[1])]
      onscreen.remove(self)
    except:
        pass
    
Shark(300,200)
Fish(300,200)
Shark(300,300)
Fish(300,300)
Shark(300,100)
Fish(300,100)
Whale(math.floor(random.randint(0,400)/10)*10,math.floor(random.randint(0,400)/10)*10)
player=Orca(60,200)  

def checkCollisions():
  if True:
    for item in onscreen:
      itemType=type(item)
      if item!=player and itemType!=Whale:
        if player.x==item.x and player.y==item.y:
          if True:
            global xp,health
            item.health-=5
            if item.health<1:
              print("Enemy Killed!")
              item.dead=True
              fill(252,32,3)
              for x in range(100):
                for y in range(100):
                  if random.randint(2,5)%2==0:
                    rect(item.x+x,item.y+y,1,1)
              time.sleep(0.1)
              xp+=(item.max_health/2)
              data["xp"]=str(xp)
              health+=item.max_health
              data["health"]=str(health)
              saveDB()
              try:
                item.kill()
              except:
                pass
              try:
                onscreen.remove(item)
              except:
                pass

def keyPressed():
  if key==CODED:
    if keyCode==RIGHT:
      player.x+=10
      checkCollisions()
    if keyCode==LEFT:
      player.x-=10
      checkCollisions()
    if keyCode==UP:
      player.y-=10
      checkCollisions()
    if keyCode==DOWN:
      player.y+=10
      checkCollisions()
      
def mouseClicked():
  for item in s_screen.btns:
    item.check(mouseX,mouseY)

whales=1

def setup():
  size(400,400)

def drawPlayerEntity(x,y):
  fill(0,0,0)
  rect(x,y,10,10)
  rect(x,y+10,10,10)
  fill(138,40,1)
  rect(x-10,y,10,10)
  rect(x+10,y,10,10)
  rect(x,y-10,10,10)
  rect(x,y+20,10,10)

def draw():
  global whales
  background(131,252,234)
  fill(0,0,0)
  rect(0,0,400,50)
  fill(255,0,0)
  textSize(20)
  text("XP:"+str(xp)+"!",0,20)
  text("HP:"+str(health)+"!",0,40)
  noStroke()
  for obj in onscreen:
    obj.check()
    obj.display()
  for obj in offscreen:
    obj.check()
  if player.health<1:
    print("GAMEOVER!!!")
    exit()
  if millis()%100==0:
    Fish(round(random.randint(0,400)/10)*10,round(random.randint(0,400)/10)*10)
  if millis()%500==0:
    Shark(round(random.randint(0,400)/10)*10,round(random.randint(0,400)/10)*10)
  if millis()%1000==0:
    Whale(round(random.randint(0,400)/10)*10,round(random.randint(0,400)/10)*10)
    whales+=1
  if whales>=3:
    for item in onscreen:
      if type(item)==Whale:
        onscreen.remove(item)
    whales=0
  s_screen.display()
  drawPlayerEntity(player.x+10,player.y+50)

run()