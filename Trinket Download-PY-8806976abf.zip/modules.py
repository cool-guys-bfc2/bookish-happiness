import random,operator,math,string,time
import urllib.request as request
from processing import*
buttons=[]
button_ids=[]
clicked=[]
hovered=[]
mouseDown=False

def mousePressed():
  mouseDown=True
  
def mouseReleased():
  mouseDown=False

def modules_draw():
  for item in buttons:
    item.display()
    hovered[item.button_num]=item.hovered()
    clicked[item.button_num]=item.clicked()

class Math(object):
  def add(a,b):
    return(a+b)
  def subtract(a,b):
    return(a-b)
  def mult(a,b):
    return(a*b)
  def div(a,b):
    return(a/b)
  def pow(a,b):
    return(a**b)
  def mod(a,b):
    return(a%b)
  def rand(a,b):
    return(round(random(a,b)))
  def conv(str):
    return(int(str))
    
class Array:
  def __init__(self):
    self.list=[]
  def createList(self,item,size):
    self.list[:]=[]    
    for i in range(size):
      self.list.append(item)
    return(self.list)
  def generateList(self,a,b,size):
    self.list[:]=[]
    for i in range(size):
      self.list.append(round(random(a,b)))
    return(self.list)
  def createArray(self,item,w,h):
    self.list[:]=[]
    for outer in range(h):
      self.list.append([])
      for inner in range(w):
        self.list[len(self.list)-1].append(item)
    return(self.list)
  def generateArray(self,a,b,w,h):
    self.list[:]=[]
    for outer in range(h):
      self.list.append([])
      for inner in range(w):
        self.list[len(self.list)-1].append(round(random(a,b)))
    return(self.list)
        
class String:
  def copy(self,str):
    return(str(str)*2)
  def conv(self,str):
    return(str(str))
  def squeeze(self,str,a,b):
    return(str[a:b])
    
class Button:
  def __init__(self,id,x,y,w,h):
    self.x,self.y=x,y
    self.w,self.h=w,h
    self.button_num=len(buttons)
    button_ids.append(id)
    clicked.append(False)
    hovered.append(False)
  def hovered(self):
    return(self.x+self.w>=mouseX
    and self.x<=mouseX
    and self.y<=mouseY
    and self.y+self.h>=mouseY)
  def clicked(self):
    return(self.hovered and mouseDown)
  def display(self):
    fill(125,125,125)
    rect(self.x,self.y,self.w,self.h)
    
class Buttons:
  def create(self,id,x,y,w,h):
    buttons.append(Button(id,x,y,w,h))
  def onclick(self,id):
    for item in buttons:
      if item.button_num==id:
        return(item.clicked())
  def onhover(self,id):
    for item in buttons:
      if item.button_num==id:
        return(item.hovered())

def installModule(module):
  if module=="math":
    math=Math()
  if module=="array":
    array=Array()
  if module=="string":
    string=String()
  if module=="sbo":
    sbo=Buttons()