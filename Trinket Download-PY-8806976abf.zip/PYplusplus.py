from processing import*
import random,operator,math,string,time
import urllib.request as request
url=""
objects=[]
r=[]
g=[]
b=[]
images=[]
imageFiles=[]
RECT="shape:001"
OVAL="shape:002"
answer=""
texts=[]
textX=[]
textY=[]

def DrawText(str,x,y):
  texts.append(str)
  textX.append(x)
  textY.append(y)
  
  
def getColor(color):
  if color=="cyan":
    return(0,255,221)
  if color=="purple":
    return(255,0,255)
  if color=="black":
    return(0,0,0)
  if color=="white":
    return(255,255,255)
  if color=="red":
    return(255,0,0)
  if color=="green":
    return(0,255,0)
  if color=="blue":
    return(4,0,255)
  if color=="yellow":
    return(242,255,0)

class Py(object):
  def __init__(self):
    self.begined=False
  def begin(self):
    self.begined=True
  def draw(self):
    if self.begined:
      textSize(20)
      text("PY++",0,20)
      r=0
      for item in objects: 
        fill(item.r,item.g,item.b)
        item.display()
        r+=1
      for item in texts:
        text(item,textX[texts.index(item)],textY[texts.index(item)])
  def load(self,file):
    if self.begined: 
      images.append(loadImage(file))
      imageFiles.append(file)
  def show(self,fileNum,x,y,w,h):
    if self.begined:
     image(images[fileNum-1],x,y,w,h)
  
class Rect(object):
  def __init__(self,x,y,w,h,r,g,b):
    self.x=x
    self.y=y
    self.w=w
    self.h=h
    self.r=r
    self.g=g
    self.b=b
    objects.append(self)
  def display(self):
    rect(self.x,self.y,self.w,self.h)
    
class Oval(object):
  def __init__(self,x,y,w,h,r,g,b):
    self.x=x
    self.y=y
    self.w=w
    self.h=h
    self.r=r
    self.g=g
    self.b=b
    objects.append(self)
  def display(self):
    ellipse(self.x,self.y,self.w,self.h)
    
class GETBPL(object):
  def __init__(self,mode="regular"):
    self.ex=mode=="extreme" or mode=="modifier"
    self.mod=mode=="modifier"
    self.inDef=False
    self.functions=[]
    self.function_values=[]
    self.inTextTag=False
    self.data=[]
  def read(self,line):
    global answer
    self.code(line)
  def value(self,value):
    if value[0]=="{" and value[len(value)-1]=="}":
      return(str(value[1:len(value)-1]))
    if value[0]=="$":
      return(int(value[1:]))
  def code(self,line):
    if line in self.functions:
      self.code(self.function_values[self.functions.index(line)])
    if line[:len("say:")]=="say:":
      print(self.value(line[len("say:"):]))
    if line[:len("readURL:")]=="readURL:" and self.ex and not self.inDef:
      print(URL(line[len("readURL:"):]))
    if line[:len("error:")]=="error:" and self.ex and not self.inDef:
      print("ERROR:"+line[len("error:"):]+"!!!")
    if line=="readPageURL()":
      print(URL_data())
    if line[:len("warn:")]=="warn:" and self.ex and not self.inDef:
      print("WARNING:"+line[len("error:"):]+"!")
    if line in self.functions and not self.inDef:
      self.read(self.function_values[self.functions.index(line)])
    if line[:len("def:")]=="def:":
      self.functions.append(line[len("def:"):])
      self.inDef=True
    if line[:len("text:")]=="text:":
      text(line[len("text:"):],0,40)
    if line[:len("ask:")]=="ask:":
      answer=input(line[len("ask:"):])
    if line[:len("respond_after:")]=="respond_after:":
      print(line[len("respond_after:"):]+answer)
    if line[:len("respond_before:")]=="respond_before:":
      print(answer+line[len("respond_before:"):])
    if self.inTextTag:
      self.data.append(line)
    if line=="<text>":
      self.data[:]=[]
      self.inTextTag=True
    if line=="</text>":
      self.inTextTag=False
      DrawText(data[0],data[1],data[2])
    if self.inDef:
      self.function_values.append(line)
      self.inDef=False
    
def centerShape():
  rectMode(CENTER)
  ellipseMode(CENTER)
  
def cornerShape():
  rectMode(CORNER)
  ellipseMode(CORNER)
    
def createShape(shape,x,y,w,h,r,g,b):
  if shape==RECT:
    rect=Rect(x,y,w,h,r,g,b)
  if shape==OVAL:
    oval=Oval(x,y,w,h,r,g,b)
    
getbplx=GETBPL("extreme")
getbpl=GETBPL()
modifier=GETBPL("modifier")
py=Py()

def URL_data():
  url=request.urlopen("https://trinket.io/python/8806976abf?toggleCode=true&runOption=run") 
  return(url.read())

def URL(url):
  url=request.urlopen(url) 
  return(url.read())