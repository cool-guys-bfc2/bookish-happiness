from processing import*
from modules import*
from PYplusplus import*

def setup():
  size(400,400)
  py.begin()
  #add your PY++ code to run once here!
  array=Array()
  string=String()
  getbplx=GETBPL("extreme")
  print(array.generateArray(0,9,10,10))
  #getbplx.read("<text>")
  #getbplx.read("Hello!")
  #getbplx.read("0")
  #getbplx.read("40")
  #getbplx.read("</text>")
  getbplx.read("def:hello")
  getbplx.read("text:hello!")

def draw():
  background(0)
  py.draw()
  modules_draw()
  #Add your PY++ code here(instant)!
  getbplx.read("hello")
  
run()