import random
#High Order Equation Evaluation
class HOEE(object):
  def __init__(self,code):
    self.code=code[:]
    self.var={}
    self.va=None
  def data(self,d):
    if d=="getlast":
      return(self.va[len(self.va)-1])
    elif d[:3]=="get":
      return(self.va[int(d[3:])])
    else:
      pass
    if d[0]=="$":
      return(self.var[d[1:]])
    if d[0]=="#":
      return(int(d[1:]))
    if d[0]=="{" and d[len(d)-1]=="}":
      array=[]
      original=d[1:-1].split("&")
      array=[self.data(item) for item in original]
      return(array)
  def val(self,v):
    answer=0
    for sym in v.split(" "):
      args=sym.split(",")
      if args[0]=="num":
        answer=float(args[1])
      elif args[0]=="int":
        answer=int(answer)
      elif args[0]=="add":
        answer+=float(args[1])
      elif args[0]=="div":
        answer/=float(args[1])
      elif args[0]=="sub":
        answer-=float(args[1])
      elif args[0]=="mult":
        answer*=float(args[1])
      elif args[0]=="pow":
        answer=answer**float(args[1])
      elif args[0]=="mod":
        answer=answer%float(args[1])
      elif args[0]=="round":
        answer=round(answer)
      elif args[0]=="rand":
        answer=random.randint(float(args[1]),float(args[2]))
      elif args[0]=="bin":
        answer=bin(int(answer))[2:]
      elif args[0]=="in":
        answer=float(input(args[1]))
      elif args[0]=="var":
        answer=int(self.var[str(args[1])])
      elif args[0]=="@":
        answer=int(self.ans)
      elif args[0]=="append":
        answer.append(self.data(args[1]))
      else:
        answer=self.data(sym)
      self.va=answer
      
    return(answer)
  def run(self):
    answer=None
    self.ans=answer
    cond=True
    for c in self.code:
      if cond:
        var=c.split("->")
        if var[0]=="@":
          answer=self.val(var[1])
          self.ans=answer
        elif var[0]=="if-res-is":
          cond=(answer==float(var[1]))
          self.ans=answer
        else:
          self.var[var[0]]=self.val(var[1])
          self.ans=answer
        if c=="@stop":
          cond=True
    return(answer)
  def edit(self,code):
    self.code=code
  def setvar(self,variable,value):
      self.var[variable]=value
  def getvar(self,variable):
      return(self.var[variable])
      
c=["a->$l getlast int add,1 round","l->$l append,$a"]
eq=HOEE(c)
eq.setvar("l",[0])
for i in range(9):
  eq.run()
print("l="+str(eq.getvar("l")))
for i in eq.getvar("l"):
  print("n="+str(i))